﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Dekor.Models;
using Dekor.Models.MetaData;
using Application = System.Windows.Application;

namespace Dekor
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static DekorEntities db = new DekorEntities();
        public App()
        {
            RegProvider<Product, MetaProduct>();
            DispatcherUnhandledException += App_DispatcherUnhandledException;
        }

        private void RegProvider<T1, T2>()
        {
            var provider = new AssociatedMetadataTypeTypeDescriptionProvider(typeof(T1), typeof(T2));
            TypeDescriptor.AddProviderTransparent(provider, typeof(T1));
        }

        
        /// <summary>
        /// </summary>

        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            MessageBox.Show("Ошибка");
        }
    }
}
