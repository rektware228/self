﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dekor.Models
{
    public partial class Product
    {
        public double Price
        {
            get
            {
                double price = 0;
                price = Product_Materials.Select(x=>x.Materials.Price.Value).Sum();

                return price;
            }

        }
    }
}
