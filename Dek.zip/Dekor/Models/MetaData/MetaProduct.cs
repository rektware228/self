﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dekor.Models.MetaData
{
    public partial class MetaProduct
    {
        

        public int Id { get; set; }
        [Required]
        [Phone]
        public string Name { get; set; }
        public int Id_Product_Type { get; set; }
        [Required(ErrorMessage ="Артикул обязателен")]
        [Range(1,1000000000)]
        public Nullable<int> Article { get; set; }
        public Nullable<double> Min_Price { get; set; }
        public Nullable<double> Width { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Application_Product> Application_Product { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Product_Materials> Product_Materials { get; set; }
        [Required]
        public virtual Product_type Product_type { get; set; }
    }
}
