﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Dekor.Models;

namespace Dekor.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        public ProductPage()
        {
            InitializeComponent();
            Refresh();

        }

        private void Refresh()
        {
            LV_Product.ItemsSource = App.db.Product.ToList();
        }

        private void BTN_Add_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditProductPage(new Models.Product()));
        }

        private void BTN_Edit_Click(object sender, RoutedEventArgs e)
        {

            if (LV_Product.SelectedItem is Product product)
            {
                NavigationService.Navigate(new AddEditProductPage(product));
            }
        }

        private void BTN_Delete_Click(object sender, RoutedEventArgs e)
        {
            if (LV_Product.SelectedItem is Product product)
            {
                App.db.Product.Remove(product);
                App.db.SaveChanges();
                Refresh();

            }
        }

        private void TB_Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        private void CBX_sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void Filter()
        {
            var data = App.db.Product.ToList();

            if (CBX_sort.SelectedIndex == 0)
            {
                data = data.OrderBy(x => x.Min_Price).ToList();
            }
            else if (CBX_sort.SelectedIndex == 1)
            {
                data = data.OrderByDescending(x => x.Min_Price).ToList();
            }
            if (!string.IsNullOrEmpty(TB_Search.Text))
            {

                data = data.Where(x => x.Name.ToLower().Contains(TB_Search.Text.ToLower())).ToList();
            }
            if (LV_Product != null)
            {

                LV_Product.ItemsSource = data;
            }

        }

        private void BTN_Materials_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MaterialPage());
        }

        private void LV_Product_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (LV_Product.SelectedItem is Product product)
            {
                NavigationService.Navigate(new AddEditProductPage(product));
            }
        }
    }
}

