﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Dekor.Models;

namespace Dekor.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductPage.xaml
    /// </summary>
    public partial class AddEditProductPage : Page
    {
        Product contextProduct;
        public AddEditProductPage(Product product)
        {
            InitializeComponent();
            this.contextProduct = product;
            DataContext = contextProduct;

            CB_type.ItemsSource = App.db.Product_type.ToList();
        }

        /// <summary>
        /// Метод для валидации модели
        /// </summary>
        /// <param name="data">Модели для проверки</param>
        /// <returns>Возращает ошибки</returns>
        private StringBuilder ValidationData<T>(T data)
        {
            var error = new StringBuilder();
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(data);
            var validationResult = new List<System.ComponentModel.DataAnnotations.ValidationResult>();
            if (!Validator.TryValidateObject(data, validationContext, validationResult, true))
            {
                foreach (var item in validationResult)
                {
                    error.AppendLine(item.ToString());
                }
            }
            return error;
        }

        private void BTN_Save_Click(object sender, RoutedEventArgs e)
        {
                var error =  ValidationData(contextProduct);
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            else
            {
                try
                {
                    if (contextProduct.Id == 0)
                    { App.db.Product.Add(contextProduct); }
                    App.db.SaveChanges();
                    NavigationService.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Заполните поля\n{ex.Message}");
                }
            }
        }

        private void BTN_Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
